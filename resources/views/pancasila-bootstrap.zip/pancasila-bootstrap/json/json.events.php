<?php

$events = array(
	array(
		'id'    => 1,
		'title' => 'Lorem ipsum dolor sit amet',
		'start' => '2015-01-01',
		'end'   => '2015-01-28',
		'color' => '#f48b31',
		'body'  => array(
			array(
				'title'   => 'Place',
				'content' => 'BINUS INTERNATIONAL SCHOOL SERPONG Jl. Lengkong Karya - Jelupang No. 58 Lengkong Karya Serpong, Tangerang, Indonesia',
			),
			array(
				'title'   => 'Link',
				'content' => '<a href="#">http://google.com</a>',
			),
		)
	),
	array(
		'id'    => 2,
		'title' => 'Lorem ipsum dolor sit amet',
		'start' => '2015-01-05',
		'end'   => '2015-01-15',
		'color' => '#f48b31',
		'body'  => array(
			array(
				'title'   => 'Place',
				'content' => 'BINUS INTERNATIONAL SCHOOL SERPONG Jl. Lengkong Karya - Jelupang No. 58 Lengkong Karya Serpong, Tangerang, Indonesia',
			),
			array(
				'title'   => 'Link',
				'content' => '<a href="#">http://google.com</a>',
			),
		)
	),
	array(
		'id'    => 3,
		'title' => 'Lorem ipsum dolor sit amet',
		'start' => '2015-01-05',
		'color' => '#f48b31',
		'body'  => array(
			array(
				'title'   => 'Place',
				'content' => 'BINUS INTERNATIONAL SCHOOL SERPONG Jl. Lengkong Karya - Jelupang No. 58 Lengkong Karya Serpong, Tangerang, Indonesia',
			),
			array(
				'title'   => 'Link',
				'content' => '<a href="#">http://google.com</a>',
			),
		)
	),
	array(
		'id'    => 4,
		'title' => 'Lorem ipsum dolor sit amet',
		'start' => '2015-01-05',
		'color' => '#f48b31',
		'body'  => array(
			array(
				'title'   => 'Place',
				'content' => 'BINUS INTERNATIONAL SCHOOL SERPONG Jl. Lengkong Karya - Jelupang No. 58 Lengkong Karya Serpong, Tangerang, Indonesia',
			),
			array(
				'title'   => 'Link',
				'content' => '<a href="#">http://google.com</a>',
			),
		)
	),
	array(
		'id'    => 5,
		'title' => 'Lorem ipsum dolor sit amet',
		'start' => '2015-01-05',
		'color' => '#f48b31',
		'body'  => array(
			array(
				'title'   => 'Place',
				'content' => 'BINUS INTERNATIONAL SCHOOL SERPONG Jl. Lengkong Karya - Jelupang No. 58 Lengkong Karya Serpong, Tangerang, Indonesia',
			),
			array(
				'title'   => 'Link',
				'content' => '<a href="#">http://google.com</a>',
			),
		)
	),
);

echo json_encode($events);