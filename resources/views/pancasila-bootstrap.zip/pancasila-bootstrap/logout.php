<?php

session_start();
unset($_SESSION['3Qg85CnALgsa']);
header('location: index.php');